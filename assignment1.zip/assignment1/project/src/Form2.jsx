import "./Form2.css";
function Form2(){
    const handlesubmit=(e)=>{
        e.preventDefault();
    }
    return(
        <form className="form" onSubmit={handlesubmit}>
            <h4 className="head">SIGNUP FORM</h4>
            <label >
                <input type="text" placeholder="First Name" className="Form2"/>
            </label><br/>
            <label >
                <input type="text" placeholder="Last Name" className="Form2"/>
            </label><br/>
            <label >
                <input type="text" placeholder="UserName" className="Form2"/>
            </label><br/>
             <label >
                <input type="text" placeholder="email" className="Form2"/>
            </label><br/>
            <label >
                <input type="password" placeholder="password" className="Form2"/>
            </label><br/>
            <label >
                <input type="number" placeholder="Phone no." className="Form2"/>
            </label><br/>
             <label >
                <input type="number" placeholder="adharcard" className="Form2"/>
            </label><br/>
            <label >Country:</label><br/>
            <select>
                <option>India</option>
                <option>US</option>
                <option>Canada</option>
            </select><br/>
            <label >city:</label><br/>
            <select>
                <option>Kanpur</option>
                <option>Bhopal</option>
                <option>Delhi</option>
            </select><br/>
            <button className="btn">Submit</button>
        </form>
    );
}
export default Form2;