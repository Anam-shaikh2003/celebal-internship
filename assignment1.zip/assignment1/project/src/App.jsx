import "./App.css"

import Reactform from "./Reactform.jsx";
  function App(){
    return (
     <>
     {/* <Form2/> */}
     {/* <Signup/> */}
    <Reactform/>
     </>
      

  )

  }
  

export default App
