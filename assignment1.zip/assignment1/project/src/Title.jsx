function Title(){
  let name="anam";
  return(
    <div>
      <h4>list</h4>
      <ul>
        <li>c++</li>
        <li>java</li>
        <li>python</li>
      </ul>
      
    </div>
    
  );
  }
export default Title